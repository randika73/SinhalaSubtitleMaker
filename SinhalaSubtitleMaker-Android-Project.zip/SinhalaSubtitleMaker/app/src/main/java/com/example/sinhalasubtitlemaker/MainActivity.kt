package com.example.sinhalasubtitlemaker

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var apiKey: EditText
    private lateinit var preview: TextView
    private var selected: Uri? = null
    private var srtText: String = ""

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selected = uri
        status.text = if (uri != null) "Video selected. Tap Generate subtitles." else "No video selected."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = EncryptedSharedPreferences.create(
            this, "secure_settings",
            MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
            layout.addView(this)
        }
        layout.addView(TextView(this).apply {
            text = "Sinhala Subtitle Maker"
            textSize = 24f
        })
        apiKey = EditText(this).apply {
            hint = "Gemini API key"
            singleLine = true
            inputType = 129
            setText(prefs.getString("gemini_key", "") ?: "")
        }
        layout.addView(apiKey)
        button("Save API key") {
            val key = apiKey.text.toString().trim()
            if (key.isBlank()) status.text = "Enter your Gemini API key first."
            else {
                prefs.edit().putString("gemini_key", key).apply()
                status.text = "API key saved securely on this phone."
            }
        }
        button("Choose video") { picker.launch("video/*") }
        button("Generate subtitles") {
            val key = prefs.getString("gemini_key", "") ?: ""
            val uri = selected
            if (key.isBlank()) { status.text = "Save your Gemini API key first."; return@button }
            if (uri == null) { status.text = "Choose a video first."; return@button }
            status.text = "Uploading video to Gemini…"
            lifecycleScope.launch {
                try {
                    val result = withContext(Dispatchers.IO) {
                        val file = copyToCache(uri)
                        GeminiClient(key).makeSubtitles(file)
                    }
                    srtText = result
                    preview.text = result
                    status.text = "Subtitles ready. Review them and export SRT."
                } catch (e: Exception) {
                    status.text = "Error: ${e.message ?: "Unknown error"}"
                }
            }
        }
        button("Export SRT") {
            if (srtText.isBlank()) { status.text = "Generate subtitles first."; return@button }
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/x-subrip"
                putExtra(Intent.EXTRA_TITLE, "subtitles.srt")
            }
            saveSrtLauncher.launch(intent)
        }
        status = TextView(this).apply { text = "Save your API key, then choose a video."; textSize = 16f }
        layout.addView(status)
        preview = TextView(this).apply { textSize = 14f; setPadding(0, 18, 0, 0) }
        layout.addView(preview)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private val saveSrtLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data ?: return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(srtText) }
            status.text = "SRT subtitle file saved."
        } catch (e: Exception) { status.text = "Save failed: ${e.message}" }
    }

    private fun copyToCache(uri: Uri): File {
        val out = File(cacheDir, "selected_video_${System.currentTimeMillis()}.mp4")
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot read selected video." }
            out.outputStream().use { output -> input.copyTo(output) }
        }
        return out
    }
}

package com.example.sinhalasubtitlemaker

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class GeminiClient(private val apiKey: String) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(10, TimeUnit.MINUTES)
        .build()

    fun makeSubtitles(video: File): String {
        require(video.length() <= 100L * 1024 * 1024) {
            "This starter version accepts videos up to 100 MB. Shorten or compress the video and try again."
        }
        val mime = when (video.extension.lowercase()) {
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            else -> "video/mp4"
        }
        val uploadStart = Request.Builder()
            .url("https://generativelanguage.googleapis.com/upload/v1beta/files?key=$apiKey")
            .header("X-Goog-Upload-Protocol", "resumable")
            .header("X-Goog-Upload-Command", "start")
            .header("X-Goog-Upload-Header-Content-Length", video.length().toString())
            .header("X-Goog-Upload-Header-Content-Type", mime)
            .header("Content-Type", "application/json")
            .post("""{"file":{"display_name":"subtitle_source"}}""".toRequestBody("application/json".toMediaType()))
            .build()
        val uploadUrl = http.newCall(uploadStart).execute().use { response ->
            if (!response.isSuccessful) error("Gemini upload setup failed (${response.code}): ${response.body?.string()}")
            response.header("X-Goog-Upload-URL") ?: error("Gemini did not return an upload URL.")
        }
        val upload = Request.Builder()
            .url(uploadUrl)
            .header("X-Goog-Upload-Offset", "0")
            .header("X-Goog-Upload-Command", "upload, finalize")
            .post(video.asRequestBody(mime.toMediaType()))
            .build()
        val fileJson = http.newCall(upload).execute().use { response ->
            if (!response.isSuccessful) error("Video upload failed (${response.code}): ${response.body?.string()}")
            JSONObject(response.body?.string() ?: error("Empty upload response"))
        }
        val fileObj = fileJson.getJSONObject("file")
        var state = fileObj.optString("state", "ACTIVE")
        val fileName = fileObj.getString("name")
        var fileUri = fileObj.getString("uri")
        repeat(30) {
            if (state == "ACTIVE") return@repeat
            Thread.sleep(2000)
            val check = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/$fileName?key=$apiKey")
                .get().build()
            val obj = http.newCall(check).execute().use { response ->
                if (!response.isSuccessful) error("Gemini file processing check failed (${response.code})")
                JSONObject(response.body?.string() ?: "{}").getJSONObject("file")
            }
            state = obj.optString("state", "ACTIVE")
            fileUri = obj.optString("uri", fileUri)
            if (state == "FAILED") error("Gemini could not process this video.")
        }
        if (state != "ACTIVE") error("Gemini video processing timed out. Try a shorter video.")
        val prompt = """
            Create subtitles for the spoken dialogue in this video.
            Preserve the language spoken: Sinhala speech must be transcribed in Sinhala script;
            English speech must remain English. Do not translate.
            Return ONLY valid JSON, no markdown fences, in this exact shape:
            {"cues":[{"start":"00:00:01.200","end":"00:00:03.400","text":"spoken words"}]}
            Use precise timestamps in HH:MM:SS.mmm format. Split into readable subtitle cues
            of roughly 1-7 seconds. Do not invent words. Include all audible speech.
        """.trimIndent()
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("file_data", JSONObject().put("mime_type", mime).put("file_uri", fileUri)))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val responseJson = http.newCall(req).execute().use { response ->
            if (!response.isSuccessful) error("Gemini request failed (${response.code}): ${response.body?.string()}")
            JSONObject(response.body?.string() ?: error("Empty Gemini response"))
        }
        val text = responseJson.getJSONArray("candidates")
            .getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            .getJSONObject(0).getString("text")
        return toSrt(JSONObject(text).getJSONArray("cues"))
    }

    private fun toSrt(cues: JSONArray): String {
        val out = StringBuilder()
        for (i in 0 until cues.length()) {
            val cue = cues.getJSONObject(i)
            out.append(i + 1).append('\n')
            out.append(toSrtTime(cue.getString("start"))).append(" --> ")
                .append(toSrtTime(cue.getString("end"))).append('\n')
            out.append(cue.getString("text").trim()).append("\n\n")
        }
        return out.toString()
    }

    private fun toSrtTime(value: String): String =
        value.replace('.', ',')
}
